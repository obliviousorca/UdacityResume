
var name = 'Rick Sanchez';
var role = 'guy who does things'

var awesomeThoughts = 'I am chris and i am AWESOME!'
var funThoughts = awesomeThoughts.replace('AWESOME','FUN');
var formattedName = HTMLheaderName.replace('%data%', name);

var formattedRole = HTMLheaderRole.replace('%data%' , role );
var skills = ['Going on wacky adventures with Morty','Gettin Shwifty','Fixing Time']
var bio = {
    'name':'Rick Sanchez',
    'role':'Science man',
    'contacts':{
        'mobile':'000-000-0000',
        'email':'rick@placeholder.gov',
        'github':'rick',
        'twitter':'@rick',
        'location':'California'

    },
    'welcomeMessage':'WUBBA LUBBA DUB DUUUUB',
    'skills':skills,
    'bioPic':'images/Rick.png'}

FormattedbioPic = HTMLbioPic.replace('%data%', bio.bioPic);
$('#header').append(FormattedbioPic)

formattedMessage = HTMLwelcomeMsg.replace('%data%', bio.welcomeMessage);  //I put the welcome message where the original top contact info was as 
$('#topContacts').append(formattedMessage)                               //I thought that the welcome message should be first and contact info last
                                                                        //rather than have contact info both which seemed like there was too much of
    

var work = {
	'jobs': [
				{
					'employer':' WITTY REFERENCE ',
					'title':' THIS IS WHERE ID PUT A HILARIOUS REFERENCE IF I HAD ONE ',
					'dates':' DOES RICK EVEN HAVE ANOTHER JOB? ',
					'location': 'California',
					'description': ' I GUESS I COULD COUNT BEING A FUGITIVE BUT WHAT WOULD I PUT FOR EMPLOYER AND STUFF? ANYWAYS CAPS LOCK IS COOL SO IM KEEPING THIS EVEN THOUGH IT MIGHT FAIL THE PROJECT WOOOOOOOOO'
				}

			]
			}

var edu = {
    'name': 'UNT',
    'degree': 'Gazorpazorp-ology',
    'dates': '1990-2050',
    'location': 'Russia',
    'major':'Wubba lubba dub dub',
    'url': 'http://www.adultswim.com/videos/rick-and-morty/'
            }

function eduStuff() {

    $('#education').append(HTMLschoolStart);

    var formattedSchool = HTMLschoolName.replace('%data%', edu.name);
    $('#education').append(formattedSchool);


    var formattedDegree = HTMLschoolDegree.replace('%data%', edu.degree);
    $('#education').append(formattedDegree);

    var formattedDates = HTMLschoolDates.replace('%data%', edu.dates);
    $('#education').append(formattedDates);

    var formattedLocation = HTMLschoolLocation.replace('%data%', edu.location);
    $('#education').append(formattedLocation);

    var formattedMajor = HTMLschoolMajor.replace('%data%', edu.major);
    $('#education').append(formattedMajor);
}


    var projects = {
        'projects': [
            {
                'title': '  Mr Meeseeks  ',
                'dates': ' season 1 episode 5 of Rick And Morty ',
                'description': ' HI IM MR MEESEEEEKSSS  ',
                'images': ["images/meeseeks.png"]
            
            }
        ]
    }
    $("#header").append(formattedName);
    $('#header').append(role);
    $('#workExperience').append(work);

    if(bio.skills.length > 0) {

        $('#header').append(HTMLskillsStart);

        var formattedSkill = HTMLskills.replace('%data%',bio.skills[0]);
        $('#skills').append(formattedSkill);
        formattedSkill = HTMLskills.replace('%data%',bio.skills[1]);
        $('#skills').append(formattedSkill);
        formattedSkill = HTMLskills.replace('%data%',bio.skills[2]);
        $('#skills').append(formattedSkill);
        formattedSkill = HTMLskills.replace('%data%',bio.skills[3]);

    }
    function displayWork() {
        for (job in work.jobs) {
            $('#workExperience').append(HTMLworkStart);

            var formattedEmployer = HTMLworkEmployer.replace('%data%', work.jobs[job].employer);

            var formattedTitle = HTMLworkTitle.replace('%data%', work.jobs[job].title);

            var formattedEmployerTitle = formattedEmployer + formattedTitle;

            $('.work-entry:last').append(
                formattedEmployerTitle);


        }


        var formattedDates = HTMLworkDates.replace('%data%', work.jobs[job].dates);
        $('.work-entry:last').append(formattedDates);
        var formattedDescription = HTMLworkDescription.replace('%data%', work.jobs[job].description);
        $('.work-entry:last').append(formattedDescription);
    }

    $(document).click(function (loc) {
        var x = loc.pageX;
        var y = loc.pageY;
        logClicks(x, y);
    });


    function projectStuff () {
        for (project in projects.projects) {
            $('#projects').append(HTMLprojectStart);

            var formattedTitle = HTMLprojectTitle.replace('%data%',
                projects.projects[project].title);
            $('.project-entry:last').append(formattedTitle);
            var formattedDates = HTMLprojectDates.replace('%data%',
                projects.projects[project].dates);
            $('.project-entry:last').append(formattedDates);
            var formattedDesc = HTMLprojectDescription.replace('%data%',
                projects.projects[project].description);
            $('.project-entry:last').append(formattedDesc);
            
            if (projects.projects[project].images.length > 0) {
                for (image in projects.projects[project].images) {
                    var formattedImage = HTMLprojectImage.replace('%data%',
                projects.projects[project].images);
                    $('.project-entry:last').append(formattedImage);
                }
            }
        }
    }
    
    function contactStuff() {

        var formattedMobile = HTMLmobile.replace('%data%', bio.contacts.mobile);
        $('#lets-connect').append(formattedMobile);

        var formattedEmail = HTMLemail.replace('%data%', bio.contacts.email);
        $('#lets-connect').append(formattedEmail);

        var formattedGithub = HTMLgithub.replace('%data%', bio.contacts.github);
        $('#lets-connect').append(formattedGithub);

        var formattedTwitter = HTMLtwitter.replace('%data%', bio.contacts.twitter);
        $('#lets-connect').append(formattedTwitter);

        var formattedLocation = HTMLlocation.replace('%data%', bio.contacts.location);
        $('#lets-connect').append(formattedLocation);
    }

    $('#mapDiv').append(googleMap);
    displayWork();
    projectStuff();
    eduStuff();
    contactStuff();

 

 
    
  




  
